---
name: lazybridge
description: >
  Use this skill whenever the user is working with LazyBridge, their custom Python
  framework for building agentic pipelines and multi-agent systems. Trigger on any
  mention of: LazyAgent, LazySession, LazyTool, LazyContext, LazyStore, LazyRouter,
  GraphSchema, lazybridge (the import or package name), or any request to build
  agent pipelines, orchestrators, multi-agent workflows, or agentic systems using
  this framework. Also trigger when the user says things like "help me write a
  pipeline", "create an agent that...", "how do I use the store", "how do I chain
  agents", etc. — even without explicit class names. When in doubt, load this skill:
  it is better to over-trigger than to miss it.
---

# LazyBridge — Skill

---

## The mental model (read this first)

> Declare topology first. Compose agents into tools. Let the framework wire the
> plumbing. Descend to lower-level APIs only when you need something the
> composition layer cannot express.

LazyBridge is built around two principles:

**Lazy evaluation.** Contexts, schemas, and tool definitions are declared at
construction time but evaluated only when a call is made. Creating
`LazyContext.from_agent(agent)` before the agent runs is safe and correct — it
evaluates when the downstream agent is called, not now.

**Composition over orchestration.** The right answer is almost always "wrap it
as a tool and let the framework wire it". Manual loops, explicit variable passing,
and boilerplate asyncio are signs you are fighting the framework.

---

## Pattern hierarchy — always start at the top

**Try each level in order. Descend only when the level above does not fit.**

```
LEVEL 1 — Composition  (try first — no plumbing, no asyncio, no context wiring)
├─ agent.as_tool()                       CANONICAL  one agent becomes a tool for another
├─ sess.as_tool(mode="parallel")         CANONICAL  fan-out; results combined automatically
├─ sess.as_tool(mode="chain")            CANONICAL  sequential pipeline; context auto-wired
└─ loop(verify=...)                      CANONICAL  quality gate / self-check on one agent

LEVEL 2 — Declared topology  (when composition does not fit the shape)
└─ LazyContext.from_agent()              STANDARD   pull-based: B sees A's output
                                                    declare at construction; execute in order
                                                    use when: agents must stay independently callable,
                                                    or topology has multiple predecessors

LEVEL 3 — Decoupled coordination  (when agents are intentionally independent)
└─ LazyStore + LazyContext.from_store()  STANDARD   blackboard model; agents write, others read
                                                    use when: cross-process, persistent, or steps skip

LEVEL 4 — Escape hatches  (only when the above do not fit)
├─ sess.gather()                         FALLBACK   raw async fan-out; use when you need per-agent .usage
├─ LazyRouter                            ADVANCED   multi-destination routing (3+ routes)
│                                                   NOT for binary pass/fail — use verify= instead
└─ Manual orchestration loops            ESCAPE     only for fully dynamic runtime graphs
```

**Descent triggers:**
- L1 → L2: pipeline is sequential but agents must remain independently callable
- L2 → L3: separate processes, persistent state, or any step may be skipped
- L3 → L4: raw response objects, multi-destination routing, truly dynamic graph

---

## Canonical forms — use these by default

| Goal | Write this |
|---|---|
| One agent calls another | `orchestrator.loop(..., tools=[agent.as_tool()])` |
| N agents run in parallel, result combined | `sess.as_tool(mode="parallel", participants=[...])` |
| Agents run sequentially, each feeds the next | `sess.as_tool(mode="chain", participants=[...])` |
| Quality gate / self-check (pass/fail) | `agent.loop(..., verify="...", max_verify=N)` |
| Read an agent's last value | `agent.result` |
| Pass agent output to next agent's context | `LazyContext.from_agent(agent)` |
| Dynamic context (date, user, config) | `LazyContext.from_function(fn)` |
| Decoupled / cross-process state | `LazyStore` + `LazyContext.from_store()` |

---

## Anti-patterns — never write these

| Anti-pattern | Problem | Instead |
|---|---|---|
| `agent._last_output` in pipeline code | Internal field; bypasses result unification | `agent.result` |
| `store.write("k", agent._last_output)` | Same anti-pattern | `store.write("k", agent.result)` |
| `resp.content` when output_schema may be set | Loses Pydantic object | `agent.result` |
| Manual `for` loop + reviewer agent for pass/fail | 30+ lines vs 3 | `loop(verify=...)` |
| `LazyRouter` for binary approve/reject | Wrong abstraction | `loop(verify=...)` |
| `sess.gather()` when only combined text needed | Requires asyncio boilerplate | `sess.as_tool(mode="parallel")` |
| `f"context: {agent._last_output}"` in system prompt | Baked at construction; breaks lazy eval | `LazyContext.from_agent(agent)` |
| `LazyStore` for tightly coupled sequential agents | Unnecessary plumbing | `sess.as_tool(mode="chain")` |
| Creating `LazyContext` after agents run | Defeats lazy evaluation | Declare context at construction |

---

## Agent result fields — which to use

| Need | Use |
|---|---|
| The typed or text output of the last call | `agent.result` ← always prefer this |
| Inject previous output into next agent's system | `LazyContext.from_agent(agent)` (reads `_last_output` internally) |
| Token usage / cost | `agent._last_response.usage` |
| Citations from web search | `agent._last_response.grounding_sources` |

**`agent.result`** — canonical public accessor. Returns a typed Pydantic object when
`output_schema` was active, plain string otherwise.

**`agent._last_output`** — always plain string. Internal field consumed by
`LazyContext.from_agent()`. Do not use in pipeline code.

**`agent._last_response`** — semi-internal. Use only for metadata (usage, citations).

---

## Method selection on a single agent

```
Need tool use?
├─ YES → loop() / aloop()
│         ├─ Need pass/fail quality gate? → loop(verify="...", max_verify=N)
│         └─ Need raw per-step events?   → loop(on_event=fn)
└─ NO
   ├─ Need structured output?  → json(msg, schema=Model) / ajson()
   ├─ Need only the string?    → text(msg) / atext()
   ├─ Need full response obj?  → chat(msg) / achat()
   └─ Need streaming?          → chat(msg, stream=True)
```

---

## Communication rules (never violate)

1. **Agents communicate via return values**, not via LazyStore.
2. **LazyStore is a blackboard for persistent/decoupled state**, not a message bus.
3. **LazyContext injects strings into system prompts** — not a communication channel.
4. **`LazyContext.from_agent(agent)`** reads `_last_output`. Safe to declare before the
   agent runs. The agent MUST have run before the downstream agent's call is made.

---

## Providers and imports

```python
from lazybridge import (
    LazyAgent, LazySession, LazyTool, LazyContext,
    LazyStore, LazyRouter, GraphSchema,
    TrackLevel, Event,
)
from lazybridge.core.types import NativeTool, ThinkingConfig
from lazybridge.core.providers.base import BaseProvider
```

| String | Provider | Env var |
|---|---|---|
| `"anthropic"` / `"claude"` | Anthropic | `ANTHROPIC_API_KEY` |
| `"openai"` / `"gpt"` | OpenAI | `OPENAI_API_KEY` |
| `"google"` / `"gemini"` | Google | `GOOGLE_API_KEY` |
| `"deepseek"` | DeepSeek | `DEEPSEEK_API_KEY` |

---

## Tracking e observability

Tracking è una feature di prima classe — non un afterthought. Usarla costa zero righe extra.

### Setup rapido

```python
# Debug in tempo reale senza aprire nessun DB
sess = LazySession(tracking="basic", console=True)

# Oppure: verbose su un singolo agente (attiva console sull'intera sessione)
agent = LazyAgent("anthropic", verbose=True)

# Persistente su SQLite — store e events nello stesso file
sess = LazySession(db="pipeline.db", tracking="basic")
```

`verbose=True` su qualsiasi agente della sessione attiva `console=True` per tutti.
`console=True` stampa ogni evento in real-time su stdout senza aprire il DB.

### TrackLevel

| Livello | Cosa logga |
|---|---|
| `"off"` | Nulla |
| `"basic"` | Tutto tranne messaggi completi, system prompt e stream chunk |
| `"verbose"` / `"full"` | Tutto, inclusi stream chunk (alto volume) |

Default: `"basic"`. Per debug di pipeline usa `"basic"` + `console=True`.
Per debug del system prompt usa `"verbose"` e leggi `Event.SYSTEM_CONTEXT`.

### Leggere gli eventi

```python
# Tutti gli eventi della sessione
sess.events.get()

# Per agente
sess.events.get(agent_id=agent.id)

# Per tipo
sess.events.get(event_type=Event.TOOL_CALL)

# Combinato con limit
sess.events.get(agent_id=agent.id, event_type=Event.MODEL_RESPONSE, limit=10)
```

Ogni evento ha: `timestamp`, `agent_id`, `agent_name`, `event_type`, `data`.

### Tipi di evento (BASIC e superiori)

| Evento | Quando |
|---|---|
| `Event.MODEL_REQUEST` | Prima di ogni chiamata LLM |
| `Event.MODEL_RESPONSE` | Dopo ogni chiamata LLM — include stop_reason e token count |
| `Event.TOOL_CALL` | Ogni invocazione di tool (nome + argomenti) |
| `Event.TOOL_RESULT` | Ritorno del tool (troncato a 500 char nel campo data) |
| `Event.TOOL_ERROR` | Eccezione durante esecuzione tool |

Solo con `"verbose"`:

| Evento | Quando |
|---|---|
| `Event.MESSAGES` | Lista completa messaggi prima di ogni chiamata |
| `Event.SYSTEM_CONTEXT` | System prompt risolto — utile per debug LazyContext |
| `Event.STREAM_CHUNK` | Ogni chunk di streaming (alto volume) |

### Pattern consigliato

```python
# Durante sviluppo: vedi tutto in real-time
sess = LazySession(db="dev.db", tracking="basic", console=True)

# In produzione: SQLite silenzioso, query post-hoc
sess = LazySession(db="prod.db", tracking="basic")

# Ispeziona costi e token usage dopo l'esecuzione
for e in sess.events.get(event_type=Event.MODEL_RESPONSE):
    print(e["agent_name"], e["data"])  # data include token counts

# Debug del system prompt risolto (context + guidance assemblati)
sess2 = LazySession(tracking="verbose")
# ... esegui pipeline ...
for e in sess2.events.get(event_type=Event.SYSTEM_CONTEXT):
    print(e["agent_name"])
    print(e["data"]["system"])
```

---

## Async rule

In any async context (`asyncio.gather`, `sess.gather()`), use the async store API:
`awrite`, `aread`, `aread_entry`, `aread_by_agent`, `adelete`, `aclear`.
Use `aloop` / `achat` / `atext` / `ajson` on agents.

---

## Reference files

Read only what the task needs. Start with `INDEX.md` when unsure.

| File | Read when |
|---|---|
| `references/INDEX.md` | Unsure where to start; class roles overview |
| `references/00_quickref.md` | Quick API signature lookup |
| `references/01_lazyagent.md` | LazyAgent params, chat/loop/as_tool, result fields |
| `references/02_lazysession.md` | LazySession, gather(), as_tool(mode=...) |
| `references/03_lazytool.md` | from_function, from_agent, specialize, save/load |
| `references/04_lazycontext.md` | from_agent, from_store, from_function, merge |
| `references/05_lazystore.md` | Store API (sync + async), SQLite backend |
| `references/06_lazyrouter.md` | LazyRouter — when and how |
| `references/07_graphschema.md` | Graph topology serialization |
| `references/08_patterns.md` | All patterns with full runnable code + style guide |
| `references/09_advanced.md` | Structured output, streaming, thinking, native tools |
| `references/10_tool_schema.md` | ToolSchemaBuilder, type mapping, LLM schema modes |
| `references/11_custom_provider.md` | BaseProvider — integrate any LLM backend |

---

## Before returning code — checklist

- [ ] Used `agent.result` (not `_last_output`) to access last value
- [ ] Used `sess.as_tool(mode="chain")` for sequential pipelines (not manual context passing)
- [ ] Used `loop(verify=...)` for pass/fail gates (not LazyRouter or manual reviewer loop)
- [ ] Declared `LazyContext` at construction time (not after agents run)
- [ ] Used async store methods in async contexts
- [ ] Used `loop()` when tools needed, `chat()` otherwise
- [ ] `LazyStore` only for genuinely decoupled/cross-process agents
- [ ] `sess.as_tool(mode="parallel")` instead of `sess.gather()` when combined output is enough
